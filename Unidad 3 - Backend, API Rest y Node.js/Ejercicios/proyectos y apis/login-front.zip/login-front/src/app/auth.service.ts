import { HttpBackend, HttpClient, HttpContext } from '@angular/common/http';
import { Injectable, SkipSelf } from '@angular/core';
import { Observable } from 'rxjs';
import { shareReplay, tap } from 'rxjs/operators';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  url = 'http://localhost:3001/api';

  constructor(private http: HttpClient, private httpBackend: HttpBackend) { }

  login(email: string, password: string) {
    return this.http.post<any>(`${this.url}/login`, { email, password })
    // Set session
    .pipe(
      tap(res => this.setSession(res)),
      shareReplay()
    );
  } 

  private setSession(authResult: any) {
    
    const expiresAt = moment().add(authResult.expiresIn,'second');

    localStorage.setItem('id_token', authResult.idToken);
    localStorage.setItem("expires_at", JSON.stringify(expiresAt.valueOf()) );
  }

  logout() {
    localStorage.removeItem("id_token");
    localStorage.removeItem("expires_at");
}

public isLoggedIn() {
    return moment().isBefore(this.getExpiration());
}

isLoggedOut() {
    return !this.isLoggedIn();
}

getExpiration() {
    const expiration = localStorage.getItem("expires_at") as string;
    const expiresAt = JSON.parse(expiration);
    return moment(expiresAt);
}    
}
